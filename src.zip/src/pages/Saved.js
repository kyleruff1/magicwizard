import React, { Component } from "react";
// import React from "react";
import Navbar from "../components/Navbar";

export default class Saved extends Component {
  render() {
    return (
      <div>
        <Navbar />
        <div className="container">
          <h1>ur saved decks will go here. nice.</h1>
          <h1>ur saved decks will go here. nice.</h1>
          <h1>ur saved decks will go here. nice.</h1>
          <h1>ur saved decks will go here. nice.</h1>
          <h1>ur saved decks will go here. nice.</h1>
          <h1>ur saved decks will go here. nice.</h1>
          <h1>ur saved decks will go here. nice.</h1>
          <h1>ur saved decks will go here. nice.</h1>
          <h1>ur saved decks will go here. nice.</h1>
          <h1>ur saved decks will go here. nice.</h1>
        </div>
      </div>
    );
  }
}
