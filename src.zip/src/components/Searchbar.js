import React from "react";

export default function Searchbar() {
  return <div></div>;
}
